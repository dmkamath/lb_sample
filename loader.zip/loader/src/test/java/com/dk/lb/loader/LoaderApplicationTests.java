package com.dk.lb.loader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
